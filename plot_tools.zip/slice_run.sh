#!/bin/bash


gcc slicing.c 

./a.out lcdm_prtcls_z_978* p lcdm_1st.txt

./a.out lin_prtcls_z_978* p lin_1st.txt

./a.out prtcls_z_978* p nl_1st.txt


./a.out lcdm_prtcls_z_-0.0* p lcdm_last.txt

./a.out lin_prtcls_z_-0.0* p lin_last.txt

./a.out prtcls_z_-0.0* p nl_last.txt



./a.out lcdm_prtcls_z_3* p lcdm_2nd.txt

./a.out lin_prtcls_z_3* p lin_2nd.txt

./a.out prtcls_z_3* p nl_2nd.txt



echo "plotting..."

gnuplot plot.gnu

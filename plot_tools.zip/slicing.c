#include <stdio.h>
#include <string.h>

#define n 64 

int main(int argc, char *argv[])
{
	FILE *fpin = fopen(argv[1],"r");
	FILE *fpout  = fopen(argv[3],"w");

	int tN = n*n*n;

	double px[3],pv[3],a;

	double x = 32,dx=2;
	int cx=-1,cy=-1,cz=-1;
	int i,j;

	puts(argv[1]);	puts(argv[2]);	puts(argv[3]);

	if(!strcmp(argv[2],"p"))
	{	
		for(i=0;i<tN;++i)
		{
			if((i%(n*n))==0)
			{	++cx;
				
			}
			if((i%n)==0)
				++cy;
			else
				++cz;

			fscanf(fpin,"%d\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\n",
					&j,&a,&px[0],&px[1],&px[2],&pv[0],&pv[1],&pv[2]);

			if((px[0]>=(x-dx))&&(px[0]<=(x+dx)))
			fprintf(fpout,"%d\t%lf\t%.20lf\t%.20lf\t%.20lf\t%.20lf\t%.20lf\t%.20lf\n",
					i,a,px[0],px[1],px[2],pv[0],pv[1],pv[2]);



		}



	}	


}
